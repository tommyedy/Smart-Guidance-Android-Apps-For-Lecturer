package com.example.smartschedule.Function;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;

public class Global {
    void generate_user_id(){

    }

    void generate_token(){

    }
    public boolean CheckValidation(GoogleSignInAccount obj){
        String email = obj.getEmail().toLowerCase();
//        String email = new String(obj.getEmail());

        String[] at = email.split("@");
        if (at[1].contains("unai.edu")){
            return true;
        }else {
            return false;
        }
    }



}
