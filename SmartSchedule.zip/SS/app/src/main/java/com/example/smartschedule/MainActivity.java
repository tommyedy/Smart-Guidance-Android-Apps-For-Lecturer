package com.example.smartschedule;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.smartschedule.Function.Connection;
import com.example.smartschedule.Function.Global;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    private Button btnSignInEmail, btnSignUpwithemail;
    private FirebaseAuth mAuth;
    Connection cd;
    GoogleSignInClient gsc;
    int RC_SIGN_IN =0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        cd = new Connection(getApplicationContext());
        if (cd.hasInternetConnection()){
            setContentView(R.layout.activity_main);
            //  mAuth = FirebaseAuth.getInstance();
            btnSignInEmail = findViewById(R.id.btnSigninwithemail);
            btnSignInEmail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (cd.hasInternetConnection()) {
                        Intent i = new Intent(MainActivity.this, SignInEmail.class);
                        startActivity(i);
//                        Intent i = new Intent(MainActivity.this, Dashboard.class);
//                        startActivity(i);
                    }else{
                        Intent i = new Intent(MainActivity.this, Try_connection.class);
                        startActivity(i);
                    }
                }
            });
            GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestEmail()
                    .build();
            gsc = GoogleSignIn.getClient(MainActivity.this, gso);

            SignInButton btnSigninGoogle = findViewById(R.id.sign_in_button);
            btnSigninGoogle.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {Signin();}
            });

            btnSignUpwithemail= findViewById(R.id.btnSignupwithemail);
            btnSignUpwithemail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (cd.hasInternetConnection()) {
                        Intent i = new Intent(MainActivity.this, SignUpEmail.class);
                        startActivity(i);
                    //    signOut();
//                        Intent i = new Intent(MainActivity.this, Dashboard.class);
//                        startActivity(i);
                    }else{
                        Intent i = new Intent(MainActivity.this, Try_connection.class);
                        startActivity(i);
                    }
                }
            });
        }else{
            Intent i = new Intent(MainActivity.this, Try_connection.class);
            startActivity(i);
        }

    }

    private void Signin(){
        Intent signInIntent = gsc.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            Global global = new Global();
            boolean check  = global.CheckValidation(account);
            if (check==false){
                Toast.makeText(getApplicationContext(),"Email Cannot be registered, use @unai.edu email", Toast.LENGTH_SHORT).show();
                signOut();
            }else {
//                Intent i = new Intent(MainActivity.this, Home_Dosen.class);
//                i.putExtra("USERNAME", account.getDisplayName().toString());
//                i.putExtra("EMAIL", account.getAccount().toString());
//                i.putExtra("ID", account.getId().toString());
//                startActivity(i);
            }
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Log.w("Error", "signInResult:failed code=" + e.getStatusCode());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.

            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);

        }
    }

//    @Override
//    protected void onStart() {
//        super.onStart();
//    }

    public void signOut(){
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        GoogleSignInClient mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        mGoogleSignInClient.signOut();
    }
}
